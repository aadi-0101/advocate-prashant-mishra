document.addEventListener("DOMContentLoaded", () => {
const track = document.querySelector(".card-track");
const carousel = document.querySelector(".card-carousel");
const nextBtn = document.getElementById("nextBtn");
const prevBtn = document.getElementById("prevBtn");

if (track && carousel && nextBtn && prevBtn) {
const originalCards = Array.from(document.querySelectorAll(".carousel-card"));
const totalCards = originalCards.length;
const gap = 20;
const autoSlideTime = 3000;
if (totalCards) {
let index = totalCards, autoSlide, isMoving = false;
const visibleCards = () => window.innerWidth <= 575 ? 1 : window.innerWidth <=991 ? 2 : window.innerWidth <=1199 ? 3 :
    4; originalCards.forEach(card=> track.insertBefore(card.cloneNode(true), track.firstChild));
    originalCards.forEach(card => track.appendChild(card.cloneNode(true)));
    const cards = Array.from(track.querySelectorAll(".carousel-card"));
    const cardWidth = () => cards[0].getBoundingClientRect().width + gap;
    const move = (instant=false) => {
    track.style.transition = instant ? "none" : "transform 0.5s ease";
    track.style.transform = `translateX(-${index * cardWidth()}px)`;
    };
    const nextSlide = () => {
    if (isMoving) return; isMoving = true; index++; move();
    setTimeout(() => { if (index >= totalCards * 2) { index = totalCards; move(true); } isMoving = false; }, 500);
    };
    const prevSlide = () => {
    if (isMoving) return; isMoving = true; index--; move();
    setTimeout(() => { if (index < totalCards) { index=totalCards * 2 - 1; move(true); } isMoving=false; }, 500); };
        const startAutoSlide=()=> { clearInterval(autoSlide); autoSlide = setInterval(nextSlide, autoSlideTime); };
        const stopAutoSlide = () => clearInterval(autoSlide);
        nextBtn.addEventListener("click", () => { nextSlide(); startAutoSlide(); });
        prevBtn.addEventListener("click", () => { prevSlide(); startAutoSlide(); });
        carousel.addEventListener("mouseenter", stopAutoSlide);
        carousel.addEventListener("mouseleave", startAutoSlide);
        window.addEventListener("resize", () => move(true));
        move(true); startAutoSlide();
        }
        }

        const year = document.getElementById("footerYear");
        if (year) year.textContent = new Date().getFullYear();
        });

/* =========================================================
   WEB3FORMS CONTACT FORM
   Create your Web3Forms access key and paste it below.
   This is the ONLY value you need to add to the website.
   ========================================================= */
const WEB3FORMS_ACCESS_KEY = "fc5c94d2-cd22-4a74-835b-55d76815f7c1";

document.addEventListener("DOMContentLoaded", () => {
    const forms = document.querySelectorAll(".web3forms-form");

    forms.forEach((form) => {
        // Add the Web3Forms access key automatically to every form.
        let accessKey = form.querySelector('input[name="access_key"]');
        if (!accessKey) {
            accessKey = document.createElement("input");
            accessKey.type = "hidden";
            accessKey.name = "access_key";
            form.appendChild(accessKey);
        }
        accessKey.value = WEB3FORMS_ACCESS_KEY;

        // Add a hidden subject field.
        let subject = form.querySelector('input[name="subject"]');
        if (!subject) {
            subject = document.createElement("input");
            subject.type = "hidden";
            subject.name = "subject";
            form.appendChild(subject);
        }
        subject.value = form.dataset.subject || "New Legal Consultation Request";

        // Honeypot spam protection.
        let botcheck = form.querySelector('input[name="botcheck"]');
        if (!botcheck) {
            botcheck = document.createElement("input");
            botcheck.type = "checkbox";
            botcheck.name = "botcheck";
            botcheck.tabIndex = -1;
            botcheck.autocomplete = "off";
            botcheck.style.display = "none";
            form.appendChild(botcheck);
        }

        // Result message without changing the existing form design.
        let result = form.querySelector(".web3forms-result");
        if (!result) {
            result = document.createElement("div");
            result.className = "web3forms-result";
            result.setAttribute("role", "status");
            result.setAttribute("aria-live", "polite");
            form.appendChild(result);
        }

        form.addEventListener("submit", async (event) => {
            event.preventDefault();

            if (!WEB3FORMS_ACCESS_KEY ||
                WEB3FORMS_ACCESS_KEY === "PASTE_YOUR_WEB3FORMS_ACCESS_KEY_HERE") {
                result.style.display = "block";
                result.textContent = "Form setup is incomplete. Add your Web3Forms Access Key in assets/js/script.js.";
                return;
            }

            const submitButton = form.querySelector('button[type="submit"]');
            const originalText = submitButton ? submitButton.textContent : "";

            if (submitButton) {
                submitButton.disabled = true;
                submitButton.textContent = "Submitting...";
            }

            result.style.display = "block";
            result.textContent = "Please wait...";

            try {
                const formData = new FormData(form);
                const response = await fetch("https://api.web3forms.com/submit", {
                    method: "POST",
                    headers: {
                        "Accept": "application/json"
                    },
                    body: formData
                });

                const data = await response.json();

                if (response.ok && data.success) {
                    result.textContent = "Thank you! Your consultation request has been submitted successfully.";
                    form.reset();
                    accessKey.value = WEB3FORMS_ACCESS_KEY;
                    subject.value = form.dataset.subject || "New Legal Consultation Request";
                    result.classList.add("success");

                    setTimeout(() => {
                        result.style.display = "none";
                        result.classList.remove("success");
                    }, 6000);
                } else {
                    result.textContent = data.message || "Unable to submit the form. Please try again.";
                    result.classList.remove("success");
                }
            } catch (error) {
                console.error("Web3Forms error:", error);
                result.textContent = "Something went wrong. Please check your internet connection and try again.";
                result.classList.remove("success");
            } finally {
                if (submitButton) {
                    submitButton.disabled = false;
                    submitButton.textContent = originalText;
                }
            }
        });
    });
});

